import os

# Paths to the source file and target file
source_file_path = r"C:\Users\coope\Desktop\Code\Python Stuff\PY-DOS-test-1'1\repair-tooling\sys-BCF.txt"
target_file_path = "PY-DOS-1'1.py"

# Ensure the source file exists
if not os.path.exists(source_file_path):
    print(f"Source file '{source_file_path}' not found.")
else:
    try:
        # Read the content from the source file
        with open(source_file_path, 'r') as source_file:
            content = source_file.read()

        # Overwrite the target file with the content from the source file
        with open(target_file_path, 'w') as target_file:
            target_file.write(content)

        print(f"File '{target_file_path}' has been overwritten with content from '{source_file_path}'.")

    except Exception as e:
        print(f"An error occurred: {e}")
