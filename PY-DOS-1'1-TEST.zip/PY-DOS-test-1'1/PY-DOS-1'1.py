import subprocess
import os
import time as t

FILE_WARDEN = 'file-warden.txt'

# ASCII Art
print(
    """.·:''''''''''''''''''''''''''':·.
: :                           : :
: :  ________  ________       : :
: : |\   ____\|\   ____\      : :
: : \ \  \___|\ \  \___|_     : :
: :  \ \  \    \ \_____  \    : :
: :   \ \  \____\|____|\  \   : :
: :    \ \_______\____\_\  \  : :
: :     \|_______|\_________\ : :
: :              \|_________| : :
: :                           : :
'·:...........................:·'"""
)
t.sleep(3)

# Loading Animation
for _ in range(12):
    print()
    t.sleep(0.02)

print(" *******   **    **        *******     *******    ********")
t.sleep(0.2)
print("/**////** //**  **        /**////**   **/////**  **////// ")
t.sleep(0.2)
print("/**   /**  //****         /**    /** **     //**/**       ")
t.sleep(0.2)
print("/*******    //**    ***** /**    /**/**      /**/*********")
t.sleep(0.2)
print("/**////      /**   /////  /**    /**/**      /**////////**")
t.sleep(0.2)
print("/**          /**          /**    ** //**     **        /**")
t.sleep(0.2)
print("/**          /**          /*******   //*******   ******** ")
t.sleep(0.2)
print("//           //           ///////     ///////   ////////  ")
print("")
print("version: 1'1 PRE-ALPHA")
t.sleep(1.5)
print("*Loading*(Need any help? Join our Discord at: https://discord.gg/Vz7QGCPd)")

def load_file_list():
    """Load the list of files from file-warden.txt."""
    if not os.path.exists(FILE_WARDEN):
        return set()
    with open(FILE_WARDEN, 'r') as f:
        return set(line.strip() for line in f)

def save_file_list(file_list):
    """Save the list of files to file-warden.txt."""
    with open(FILE_WARDEN, 'w') as f:
        for file_name in file_list:
            f.write(f"{file_name}\n")

def add_files(file_names):
    """Add new files with content and update file-warden.txt."""
    file_list = load_file_list()
    for file_name in file_names:
        if file_name not in file_list:
            content = input(f"Enter content for {file_name} (press Enter for empty file): ")
            with open(file_name, 'w') as f:  # Create the file and write content
                f.write(content)
            file_list.add(file_name)
            print(f"File added: {file_name}")
        else:
            print(f"File already exists: {file_name}")
    save_file_list(file_list)

def delete_files(file_names):
    """Delete files and update file-warden.txt."""
    file_list = load_file_list()
    for file_name in file_names:
        if file_name in file_list:
            try:
                os.remove(file_name)
                file_list.remove(file_name)
                print(f"File deleted: {file_name}")
            except FileNotFoundError:
                print(f"File not found: {file_name}")
        else:
            print(f"File not listed: {file_name}")
    save_file_list(file_list)

import psutil
import time

def monitor_system():

    # CPU usage
    cpu_usage = psutil.cpu_percent(interval=1)        
    # RAM usage
    memory_info = psutil.virtual_memory()
    total_ram = memory_info.total / (1024 ** 3)
    available_ram = memory_info.available / (1024 ** 3)
    used_ram = memory_info.used / (1024 ** 3)
    ram_percent = memory_info.percent

    # Print system information
    print(f"CPU Usage: {cpu_usage}%")
    print(f"Total RAM: {total_ram:.2f} GB")
    print(f"Available RAM: {available_ram:.2f} GB")
    print(f"Used RAM: {used_ram:.2f} GB")
    print(f"RAM Usage: {ram_percent}%")
    print("-" * 30)
        


def run_cmd():
    print("Cmd launched. You can start typing commands. Type 'exit' to quit.")
    while True:
        # Get user input
        user_input = input("cmd> ")
        
        if user_input.lower() == "exit":
            break

        # Execute the command and capture output
        process = subprocess.run(
            user_input,                  # Command to run
            shell=True,                  # Use the shell
            capture_output=True,         # Capture stdout and stderr
            text=True                     # Handle output as text
        )

        # Print the output and errors
        if process.stdout:
            print(f"Output: {process.stdout.strip()}")
        if process.stderr:
            print(f"Error: {process.stderr.strip()}")

def progress_bar(total, step, speed):
    for i in range(0, total + 1, step):
        percent = (i / total) * 100
        bar = '=' * int(percent // 2) + ' ' * (50 - int(percent // 2))
        print(f'\r[{bar}] {percent:.2f}%', end='')
        t.sleep(speed)
    print()  # Move to the next line after completion

def file_management():
    while True:
        action = input("File Management: 1 to add files, 2 to delete files, 3 to return to main menu: ")
        if action == '1':
            files = input("Enter filenames to add (comma-separated): ").split(',')
            add_files(file.strip() for file in files)
        elif action == '2':
            files = input("Enter filenames to delete (comma-separated): ").split(',')
            delete_files(file.strip() for file in files)
        elif action == '3':
            break
        else:
            print("Invalid option. Please choose again.")

# Main Program
progress_bar(total=100, step=1, speed=0.050)
print("Loading Done!")

ite = 1
while ite == 1:
    user_select = input("1 to open files, 2 to open MSedge, 3 to open cmd interface, 4 to open calculator, 5 to open RDL menu (Repair.Diagnostics.Links): ")
    if (int(user_select)) == 1:
        file_management()
    elif (int(user_select)) == 2:
        print("2. Accepted")
        os.system("start msedge")
    elif (int(user_select)) == 3:
        print("3. Accepted")
        cmd_control = (int(input("Press 1 to start a new window, 2 to use the cmd CLI pipe: ")))
        if cmd_control == 1:
            os.system("start cmd")
        elif cmd_control == 2:
            run_cmd()
    elif (int(user_select)) == 4:
        print("4. Accepted")
        os.system("start calc")
    elif (int(user_select)) == 5:
        print("5. Accepted")
        RDL_control=input("Do want to (R)epair, open (D)iagnostics or open (L)inks?:  ")
        if RDL_control=="R":
            # Path to the script you want to run
            script_to_run = "repair-tool-1'1.py"


            # Use subprocess to run the script
            subprocess.run(['python', script_to_run])

            print(f"'{script_to_run}' has been executed.")
        elif RDL_control=="D":
            monitor_system()

    else:
        print("Invalid option. Please choose again.")

    ite = (int(input("Do you want to go back to beginning? (1=yes anything but 1: no): ")))